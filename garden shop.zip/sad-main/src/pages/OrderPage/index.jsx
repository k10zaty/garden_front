import React from 'react';
import styles from './OrderPage.module.css';

const OrderPage = () => {
  return <div className={styles.order}>OrderPage</div>;
};

export default OrderPage; 